package test2_1;
interface KMenu
{
	public void systemOn();		// 메뉴 가동 메소드
	
	public void menuDisp();		// 메뉴 표시 메소드

	public void menuSelect();	// 메뉴 선택 메소드

	public void menuRun();		// 메뉴 실행 메소드
}